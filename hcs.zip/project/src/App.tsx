import React, { useState, useEffect } from 'react';
import { ChevronDown, CheckSquare, ArrowRight } from 'lucide-react';
import { ThemeToggle } from './components/ThemeToggle';
import { Chatbot } from './components/Chatbot';
import { PricingCalculator } from './components/PricingCalculator';
import { ContactPage } from './components/ContactPage';
import { MobileMenu } from './components/MobileMenu';
import { Testimonials } from './components/Testimonials';
import { NewsSection } from './components/NewsSection';
import { Achievements } from './components/Achievements';
import { BookingModal } from './components/BookingModal';

function App() {
  const [activeDropdown, setActiveDropdown] = useState<string | null>(null);
  const [isScrolled, setIsScrolled] = useState(false);
  const [showContactPage, setShowContactPage] = useState(false);
  const [showBookingModal, setShowBookingModal] = useState(false);

  useEffect(() => {
    const handleScroll = () => {
      setIsScrolled(window.scrollY > 0);

      const animatedElements = document.querySelectorAll(
        '.animate-slide-in, .animate-slide-left, .animate-slide-right, .animate-slide-top'
      );

      animatedElements.forEach((element) => {
        const elementTop = element.getBoundingClientRect().top;
        const elementBottom = element.getBoundingClientRect().bottom;
        const isVisible = elementTop < window.innerHeight - 100 && elementBottom > 0;

        if (isVisible) {
          element.classList.add('visible');
        }
      });
    };

    window.addEventListener('scroll', handleScroll);
    handleScroll();
    
    return () => window.removeEventListener('scroll', handleScroll);
  }, []);

  const dropdownMenus = {
    'Who We Are': ['Overview', 'Experience', 'People', 'Careers', 'Partners'],
    'Workflows': ['Clinical', 'Financial', 'Operational', 'Compliance'],
    'Products': ['Behavioral Record', 'Revenue Cycle Management', 'Order Management', 'Patient Safety', 'Compliance Toolkit'],
    'Support': ['Software Support', 'Virtual Training'],
    'Resources': ['News', 'HCS Events', 'Patient Safety Resources']
  };

  const Logo = () => (
    <div 
      onClick={() => setShowContactPage(false)} 
      className="text-emerald-600 dark:text-emerald-400 font-bold text-3xl tracking-tight cursor-pointer"
    >
      HCS
      <div className="text-xs text-gray-600 dark:text-gray-400 font-normal tracking-normal mt-[-2px]">
        Health Care Systems
      </div>
    </div>
  );

  if (showContactPage) {
    return (
      <ContactPage 
        onBack={() => setShowContactPage(false)} 
        dropdownMenus={dropdownMenus} 
        Logo={Logo} 
      />
    );
  }

  return (
    <div className="min-h-screen bg-white dark:bg-gray-900 transition-colors duration-200">
      {/* Navigation */}
      <nav className={`py-4 bg-white dark:bg-gray-900 fixed w-full top-0 z-50 transition-all duration-300 ${
        isScrolled ? 'shadow-md dark:shadow-gray-800' : ''
      }`}>
        <div className="max-w-7xl mx-auto px-6">
          <div className="flex items-center justify-between">
            {/* Logo */}
            <div className="flex-shrink-0">
              <Logo />
            </div>

            {/* Main Navigation */}
            <div className="hidden lg:flex items-center space-x-8">
              {Object.entries(dropdownMenus).map(([menu, items]) => (
                <div key={menu} className="relative">
                  <button 
                    className="flex items-center space-x-1 text-gray-800 dark:text-gray-200 hover:text-emerald-600 dark:hover:text-emerald-400 py-2 text-sm font-medium"
                    onMouseEnter={() => setActiveDropdown(menu)}
                    onClick={() => setActiveDropdown(activeDropdown === menu ? null : menu)}
                  >
                    <span>{menu}</span>
                    <ChevronDown className="h-4 w-4" />
                  </button>
                  {activeDropdown === menu && (
                    <div 
                      className="absolute top-full left-0 mt-1 w-48 bg-white dark:bg-gray-800 rounded-md shadow-lg py-2"
                      onMouseLeave={() => setActiveDropdown(null)}
                    >
                      {items.map((item) => (
                        <a
                          key={item}
                          href="#"
                          className="block px-4 py-2 text-sm text-gray-700 dark:text-gray-300 hover:bg-emerald-50 dark:hover:bg-emerald-900/20 hover:text-emerald-600 dark:hover:text-emerald-400"
                        >
                          {item}
                        </a>
                      ))}
                    </div>
                  )}
                </div>
              ))}
              <button 
                onClick={() => setShowContactPage(true)}
                className="text-gray-800 dark:text-gray-200 hover:text-emerald-600 dark:hover:text-emerald-400 text-sm font-medium"
              >
                Contact Us
              </button>
            </div>

            <div className="flex items-center space-x-4">
              <ThemeToggle />
              <button 
                onClick={() => setShowBookingModal(true)}
                className="hidden sm:block bg-emerald-500 dark:bg-emerald-600 text-white px-6 py-2 rounded-full text-sm font-medium hover:bg-emerald-600 dark:hover:bg-emerald-700 transition-colors"
              >
                Book a Demo
              </button>
              <MobileMenu 
                dropdownMenus={dropdownMenus}
                onContactClick={() => setShowContactPage(true)}
                onBookDemo={() => setShowBookingModal(true)}
              />
            </div>
          </div>
        </div>
      </nav>

      {/* Add padding to account for fixed navbar */}
      <div className="pt-20"></div>

      {/* Hero Section */}
      <section className="relative h-[800px] md:h-[600px] lg:h-[800px] overflow-hidden">
        {/* Wave background */}
        <div className="absolute inset-0">
          <div className="absolute inset-0 bg-gradient-to-r from-emerald-50/70 to-teal-50/70 dark:from-emerald-900/30 dark:to-teal-900/30"></div>
          <div className="absolute inset-0">
            <svg
              viewBox="0 0 1440 320"
              className="absolute w-full h-full"
              preserveAspectRatio="none"
              style={{ transform: 'scale(1.5)' }}
            >
              <path
                fill="rgb(236 254 255 / 0.5)"
                d="M0,160L48,144C96,128,192,96,288,106.7C384,117,480,171,576,165.3C672,160,768,96,864,74.7C960,53,1056,75,1152,90.7C1248,107,1344,117,1392,122.7L1440,128L1440,320L1392,320C1344,320,1248,320,1152,320C1056,320,960,320,864,320C768,320,672,320,576,320C480,320,384,320,288,320C192,320,96,320,48,320L0,320Z"
                className="dark:fill-emerald-900/20"
              ></path>
            </svg>
          </div>
        </div>

        {/* Content container */}
        <div className="relative max-w-[1400px] mx-auto px-4 h-full">
          {/* Images */}
          <div className="relative h-full">
            {/* Images for desktop */}
            <div className="hidden lg:block">
              {/* Top image */}
              <div className="absolute top-[80px] right-[25%] w-[450px] h-[280px] animate-slide-top">
                <div className="relative w-full h-full rounded-2xl overflow-hidden shadow-xl" style={{ transform: 'perspective(1000px) rotateX(5deg)' }}>
                  <img 
                    src="https://images.unsplash.com/photo-1537368910025-700350fe46c7?q=80&w=3540&auto=format&fit=crop"
                    alt="Healthcare professional"
                    className="w-full h-full object-cover"
                  />
                </div>
              </div>

              {/* Bottom left image */}
              <div className="absolute bottom-[120px] left-[15%] w-[450px] h-[280px] animate-slide-left">
                <div className="relative w-full h-full rounded-2xl overflow-hidden shadow-xl" style={{ transform: 'perspective(1000px) rotateX(-5deg)' }}>
                  <img 
                    src="https://images.unsplash.com/photo-1576765608535-5f04d1e3f289?q=80&w=3478&auto=format&fit=crop"
                    alt="Healthcare consultation"
                    className="w-full h-full object-cover"
                  />
                </div>
              </div>

              {/* Bottom right image */}
              <div className="absolute bottom-[120px] right-[10%] w-[450px] h-[280px] animate-slide-right">
                <div className="relative w-full h-full rounded-2xl overflow-hidden shadow-xl" style={{ transform: 'perspective(1000px) rotateX(-5deg)' }}>
                  <img 
                    src="https://images.unsplash.com/photo-1590105577767-e21a1067899f?q=80&w=3432&auto=format&fit=crop"
                    alt="Healthcare technology"
                    className="w-full h-full object-cover"
                  />
                </div>
              </div>
            </div>

            {/* Images for mobile */}
            <div className="lg:hidden grid grid-cols-1 md:grid-cols-3 gap-4 pt-8">
              <div className="rounded-xl overflow-hidden shadow-lg h-48 animate-slide-left">
                <img 
                  src="https://images.unsplash.com/photo-1537368910025-700350fe46c7?q=80&w=3540&auto=format&fit=crop"
                  alt="Healthcare professional"
                  className="w-full h-full object-cover"
                />
              </div>
              <div className="rounded-xl overflow-hidden shadow-lg h-48 animate-slide-top">
                <img 
                  src="https://images.unsplash.com/photo-1576765608535-5f04d1e3f289?q=80&w=3478&auto=format&fit=crop"
                  alt="Healthcare consultation"
                  className="w-full h-full object-cover"
                />
              </div>
              <div className="rounded-xl overflow-hidden shadow-lg h-48 animate-slide-right">
                <img 
                  src="https://images.unsplash.com/photo-1590105577767-e21a1067899f?q=80&w=3432&auto=format&fit=crop"
                  alt="Healthcare technology"
                  className="w-full h-full object-cover"
                />
              </div>
            </div>

            {/* Centered text */}
            <div className="absolute top-1/2 left-1/2 transform -translate-x-1/2 -translate-y-1/2 text-center w-full px-4">
              <h1 className="text-4xl md:text-6xl lg:text-[120px] font-bold leading-tight animate-slide-in">
                <span className="bg-gradient-to-r from-emerald-500 via-emerald-400 to-teal-400 bg-clip-text text-transparent dark:from-emerald-400 dark:via-emerald-500 dark:to-teal-400">
                  We Are Behavioral Health
                </span>
              </h1>
            </div>
          </div>
        </div>
      </section>

      {/* Achievements Section */}
      <Achievements />

      {/* Experts Section */}
      <section className="py-24 mt-32">
        <div className="max-w-4xl mx-auto px-4">
          <div className="flex flex-col lg:flex-row items-start justify-between gap-12">
            <div className="max-w-md animate-slide-in">
              <h2 className="text-2xl font-bold mb-4 dark:text-white">Your Behavioral Health Technology Experts</h2>
              <p className="text-gray-600 dark:text-gray-400 text-sm mb-6 leading-relaxed">
                We are a leading provider of innovative technology solutions for Behavioral Health, offering a comprehensive infrastructure that streamlines clinical and financial workflows with a patient-focused approach.
              </p>
              <button className="bg-emerald-500 text-white text-sm px-6 py-2 rounded-md hover:bg-emerald-600 transition-colors">
                About HCS
              </button>
            </div>
            <img 
              src="https://images.unsplash.com/photo-1573497019940-1c28c88b4f3e" 
              alt="Healthcare professional" 
              className="w-full lg:w-96 rounded-lg animate-slide-right"
            />
          </div>
        </div>
      </section>

      {/* Testimonials Section */}
      <Testimonials />

      {/* Workflows Section */}
      <section className="py-24">
        <div className="max-w-4xl mx-auto px-4">
          <h2 className="text-2xl font-bold mb-12 text-center dark:text-white animate-slide-in">Workflows</h2>
          <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-6">
            {[
              {
                name: 'Clinical',
                image: 'https://images.unsplash.com/photo-1576091160550-2173dba999ef'
              },
              {
                name: 'Financial',
                image: 'https://images.unsplash.com/photo-1554224155-8d04cb21cd6c'
              },
              {
                name: 'Operational',
                image: 'https://images.unsplash.com/photo-1576091160399-112ba8d25d1d'
              },
              {
                name: 'Compliance',
                image: 'https://images.unsplash.com/photo-1454165804606-c3d57bc86b40'
              }
            ].map((workflow, index) => (
              <div key={workflow.name} className={`bg-white dark:bg-gray-800 rounded-lg shadow-sm p-4 animate-slide-in`}>
                <img 
                  src={workflow.image}
                  alt={workflow.name}
                  className="w-full h-32 object-cover rounded-lg mb-4"
                />
                <h3 className="text-sm font-medium text-center dark:text-white">{workflow.name}</h3>
              </div>
            ))}
          </div>
        </div>
      </section>

      {/* Products Section */}
      <section className="py-24">
        <div className="max-w-4xl mx-auto px-4">
          <h2 className="text-2xl font-bold mb-8 dark:text-white animate-slide-in">Products We Offer</h2>
          <div className="space-y-6">
            {[
              { name: 'Behavioral Record', iconColor: 'text-emerald-500', bgColor: 'bg-emerald-500/10' },
              { name: 'Revenue Cycle Management', iconColor: 'text-emerald-500', bgColor: 'bg-emerald-500/10' },
              { name: 'Order Management', iconColor: 'text-emerald-900', bgColor: 'bg-emerald-900/10' },
              { name: 'Patient Safety', iconColor: 'text-teal-500', bgColor: 'bg-teal-500/10' },
              { name: 'Compliance Toolkit', iconColor: 'text-teal-500', bgColor: 'bg-teal-500/10' }
            ].map((product) => (
              <div 
                key={product.name} 
                className="flex items-center justify-between py-6 border-b border-gray-100 dark:border-gray-800 animate-slide-in hover:bg-gray-50 dark:hover:bg-gray-800/50 transition-colors px-4 rounded-lg cursor-pointer group"
              >
                <div className="flex items-center space-x-4">
                  <div className={`p-2 rounded-lg ${product.bgColor}`}>
                    <CheckSquare className={`w-6 h-6 ${product.iconColor}`} />
                  </div>
                  <span className="text-lg font-medium dark:text-white">{product.name}</span>
                </div>
                <ArrowRight className="w-6 h-6 text-emerald-500 transform group-hover:translate-x-1 transition-transform" />
              </div>
            ))}
          </div>
        </div>
      </section>

      {/* News Section */}
      <NewsSection />

      {/* Footer */}
      <footer className="bg-white dark:bg-gray-900 py-12 border-t border-gray-100 dark:border-gray-800">
        <div className="max-w-4xl mx-auto px-4">
          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-8">
            <div className="animate-slide-in">
              <div className="text-emerald-500 dark:text-emerald-400 font-bold text-xl mb-4">HCS</div>
              <p className="text-gray-600 dark:text-gray-400 text-sm">Your trusted behavioral health technology partner</p>
            </div>
            <div className="animate-slide-in">
              <h3 className="font-medium mb-4 text-sm dark:text-white">Who we are</h3>
              <ul className="space-y-2 text-sm">
                <li><a href="#" className="text-gray-500 dark:text-gray-400 hover:text-emerald-500 dark:hover:text-emerald-400">Overview</a></li>
                <li><a href="#" className="text-gray-500 dark:text-gray-400 hover:text-emerald-500 dark:hover:text-emerald-400">Experience</a></li>
              </ul>
            </div>
            <div className="animate-slide-in">
              <h3 className="font-medium mb-4 text-sm dark:text-white">Support</h3>
              <ul className="space-y-2 text-sm">
                <li><a href="#" className="text-gray-500 dark:text-gray-400 hover:text-emerald-500 dark:hover:text-emerald-400">Software Support</a></li>
                <li><a href="#" className="text-gray-500 dark:text-gray-400 hover:text-emerald-500 dark:hover:text-emerald-400">Virtual Training</a></li>
              </ul>
            </div>
            <div className="animate-slide-in">
              <h3 className="font-medium mb-4 text-sm dark:text-white">Contact Us</h3>
              <p className="text-gray-500 dark:text-gray-400 text-sm">5755 Carmichael Parkway</p>
              <p className="text-gray-500 dark:text-gray-400 text-sm mb-4">Montgomery, AL 36117</p>
              <button 
                onClick={() => setShowBookingModal(true)}
                className="bg-emerald-500 text-white px-4 py-2 rounded-md text-sm hover:bg-emerald-600 transition-colors"
              >
                Book a Demo
              </button>
            </div>
          </div>
        </div>
      </footer>

      {/* Floating Components */}
      <Chatbot />
      <PricingCalculator />

      {/* Booking Modal */}
      <BookingModal 
        isOpen={showBookingModal}
        onClose={() => setShowBookingModal(false)}
      />
    </div>
  );
}

export default App;