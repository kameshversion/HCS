import React, { useState } from 'react';
import { Menu, Transition } from '@headlessui/react';
import { Menu as MenuIcon, X, ChevronDown, ChevronRight } from 'lucide-react';

interface MobileMenuProps {
  dropdownMenus: Record<string, string[]>;
  onContactClick: () => void;
  onBookDemo: () => void;
}

export function MobileMenu({ dropdownMenus, onContactClick, onBookDemo }: MobileMenuProps) {
  const [openSection, setOpenSection] = useState<string | null>(null);

  return (
    <Menu as="div" className="relative lg:hidden">
      {({ open }) => (
        <>
          <Menu.Button className="p-2 text-gray-600 hover:text-gray-900 dark:text-gray-300 dark:hover:text-white">
            {open ? (
              <X className="h-6 w-6" />
            ) : (
              <MenuIcon className="h-6 w-6" />
            )}
          </Menu.Button>

          <Transition
            show={open}
            enter="transition duration-100 ease-out"
            enterFrom="transform scale-95 opacity-0"
            enterTo="transform scale-100 opacity-100"
            leave="transition duration-75 ease-out"
            leaveFrom="transform scale-100 opacity-100"
            leaveTo="transform scale-95 opacity-0"
          >
            <Menu.Items
              static
              className="absolute right-0 mt-2 w-64 origin-top-right bg-white dark:bg-gray-800 rounded-lg shadow-lg ring-1 ring-black ring-opacity-5 focus:outline-none max-h-[80vh] overflow-hidden flex flex-col"
            >
              <div className="overflow-y-auto py-2">
                {Object.entries(dropdownMenus).map(([menu, items]) => (
                  <div key={menu} className="border-b border-gray-100 dark:border-gray-700 last:border-0">
                    <button
                      onClick={() => setOpenSection(openSection === menu ? null : menu)}
                      className="w-full flex items-center justify-between px-4 py-3 text-sm font-medium text-gray-700 dark:text-gray-200 hover:bg-gray-50 dark:hover:bg-gray-700"
                    >
                      {menu}
                      {openSection === menu ? (
                        <ChevronDown className="h-4 w-4" />
                      ) : (
                        <ChevronRight className="h-4 w-4" />
                      )}
                    </button>
                    <Transition
                      show={openSection === menu}
                      enter="transition-all duration-200 ease-out"
                      enterFrom="opacity-0 max-h-0"
                      enterTo="opacity-100 max-h-96"
                      leave="transition-all duration-150 ease-in"
                      leaveFrom="opacity-100 max-h-96"
                      leaveTo="opacity-0 max-h-0"
                      className="overflow-hidden"
                    >
                      <div className="bg-gray-50 dark:bg-gray-700/50">
                        {items.map((item) => (
                          <Menu.Item key={item}>
                            {({ active }) => (
                              <a
                                href="#"
                                className={`${
                                  active
                                    ? 'bg-gray-100 dark:bg-gray-600 text-[#0072CE] dark:text-blue-400'
                                    : 'text-gray-600 dark:text-gray-300'
                                } block px-6 py-2 text-sm`}
                              >
                                {item}
                              </a>
                            )}
                          </Menu.Item>
                        ))}
                      </div>
                    </Transition>
                  </div>
                ))}
                <Menu.Item>
                  {({ active }) => (
                    <button
                      onClick={onContactClick}
                      className={`${
                        active
                          ? 'bg-gray-50 dark:bg-gray-700 text-[#0072CE] dark:text-blue-400'
                          : 'text-gray-700 dark:text-gray-200'
                      } block w-full text-left px-4 py-3 text-sm font-medium`}
                    >
                      Contact Us
                    </button>
                  )}
                </Menu.Item>
              </div>
              <div className="p-4 border-t border-gray-100 dark:border-gray-700 mt-auto">
                <button 
                  onClick={onBookDemo}
                  className="w-full bg-[#90E0EF] dark:bg-blue-600 text-white px-4 py-2 rounded-full text-sm font-medium hover:bg-[#48CAE4] dark:hover:bg-blue-700 transition-colors"
                >
                  Book a Demo
                </button>
              </div>
            </Menu.Items>
          </Transition>
        </>
      )}
    </Menu>
  );
}