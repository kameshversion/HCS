import React from 'react';

export function HCSLogo() {
  return (
    <div className="text-[#0072CE] dark:text-blue-400 font-bold text-3xl tracking-tight">
      HCS
      <div className="text-xs text-[#666666] dark:text-gray-400 font-normal tracking-normal mt-[-2px]">
        Health Care Systems
      </div>
    </div>
  );
}