import React, { useEffect, useRef, useState } from 'react';
import { Users, Building2, Award, Heart } from 'lucide-react';

export function Achievements() {
  const [isVisible, setIsVisible] = useState(false);
  const sectionRef = useRef<HTMLDivElement>(null);

  const achievements = [
    {
      icon: Users,
      number: 5000,
      label: "Healthcare Providers",
      suffix: "+"
    },
    {
      icon: Building2,
      number: 500,
      label: "Partner Facilities",
      suffix: "+"
    },
    {
      icon: Award,
      number: 25,
      label: "Years Experience",
      suffix: ""
    },
    {
      icon: Heart,
      number: 1000000,
      label: "Patients Served",
      suffix: "+"
    }
  ];

  useEffect(() => {
    const observer = new IntersectionObserver(
      ([entry]) => {
        if (entry.isIntersecting) {
          setIsVisible(true);
        }
      },
      { threshold: 0.1 }
    );

    if (sectionRef.current) {
      observer.observe(sectionRef.current);
    }

    return () => observer.disconnect();
  }, []);

  return (
    <section 
      ref={sectionRef}
      className="py-24 bg-gradient-to-r from-blue-50 to-teal-50 dark:from-gray-800 dark:to-gray-900"
    >
      <div className="max-w-7xl mx-auto px-6">
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-8">
          {achievements.map((achievement, index) => (
            <div 
              key={index}
              className="text-center animate-slide-in"
            >
              <div className="inline-block p-4 rounded-full bg-blue-100 dark:bg-blue-900/50 mb-4">
                <achievement.icon className="w-8 h-8 text-blue-500" />
              </div>
              <div className="text-4xl font-bold mb-2 text-gray-800 dark:text-white">
                {isVisible ? (
                  <CountUp
                    end={achievement.number}
                    suffix={achievement.suffix}
                  />
                ) : (
                  "0" + achievement.suffix
                )}
              </div>
              <p className="text-gray-600 dark:text-gray-300">
                {achievement.label}
              </p>
            </div>
          ))}
        </div>
      </div>
    </section>
  );
}

function CountUp({ end, suffix = "" }) {
  const [count, setCount] = useState(0);
  
  useEffect(() => {
    const duration = 2000; // 2 seconds
    const steps = 60;
    const increment = end / steps;
    let current = 0;
    
    const timer = setInterval(() => {
      current += increment;
      if (current >= end) {
        setCount(end);
        clearInterval(timer);
      } else {
        setCount(Math.floor(current));
      }
    }, duration / steps);
    
    return () => clearInterval(timer);
  }, [end]);
  
  return <>{count.toLocaleString() + suffix}</>;
}