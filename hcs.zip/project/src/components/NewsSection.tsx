import React from 'react';
import { ArrowRight } from 'lucide-react';

export function NewsSection() {
  const news = [
    {
      image: "https://images.unsplash.com/photo-1551076805-e1869033e561?auto=format&fit=crop&w=800&q=80",
      title: "New Mental Health Integration Features Released",
      preview: "Enhancing patient care with seamless mental health record integration...",
      date: "Mar 15, 2024"
    },
    {
      image: "https://images.unsplash.com/photo-1576091160550-2173dba999ef?auto=format&fit=crop&w=800&q=80",
      title: "HCS Recognized for Innovation in Healthcare Tech",
      preview: "Leading industry award acknowledges our commitment to advancing healthcare...",
      date: "Mar 10, 2024"
    },
    {
      image: "https://images.unsplash.com/photo-1587854692152-cbe660dbde88?auto=format&fit=crop&w=800&q=80",
      title: "2024 Healthcare Compliance Update",
      preview: "Stay compliant with the latest regulatory changes in behavioral health...",
      date: "Mar 5, 2024"
    }
  ];

  return (
    <section className="py-24 bg-white dark:bg-gray-900">
      <div className="max-w-7xl mx-auto px-6">
        <div className="flex justify-between items-center mb-12">
          <h2 className="text-3xl font-bold dark:text-white animate-slide-in">
            Latest Updates
          </h2>
          <a 
            href="#" 
            className="flex items-center text-blue-500 hover:text-blue-600 transition-colors"
          >
            View All News
            <ArrowRight className="ml-2 w-4 h-4" />
          </a>
        </div>
        <div className="grid grid-cols-1 md:grid-cols-3 gap-8">
          {news.map((item, index) => (
            <div 
              key={index}
              className="group cursor-pointer animate-slide-in"
            >
              <div className="overflow-hidden rounded-xl mb-4">
                <img 
                  src={item.image}
                  alt={item.title}
                  className="w-full h-48 object-cover transform group-hover:scale-105 transition-transform duration-300"
                />
              </div>
              <p className="text-sm text-gray-500 dark:text-gray-400 mb-2">
                {item.date}
              </p>
              <h3 className="text-xl font-semibold mb-2 group-hover:text-blue-500 transition-colors dark:text-white">
                {item.title}
              </h3>
              <p className="text-gray-600 dark:text-gray-300">
                {item.preview}
              </p>
            </div>
          ))}
        </div>
      </div>
    </section>
  );
}