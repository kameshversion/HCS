import React from 'react';
import { Quote } from 'lucide-react';

export function Testimonials() {
  const testimonials = [
    {
      quote: "HCS has transformed our behavioral health practice. Their software is intuitive and has significantly improved our workflow.",
      author: "Dr. Sarah Johnson",
      role: "Clinical Director",
      organization: "Mindful Health Center"
    },
    {
      quote: "The support team is exceptional. They're always available and truly understand healthcare operations.",
      author: "Michael Chen",
      role: "Operations Manager",
      organization: "Behavioral Care Partners"
    },
    {
      quote: "Implementation was smooth, and the ROI has been remarkable. Our efficiency has improved by 40%.",
      author: "Lisa Rodriguez",
      role: "CEO",
      organization: "Wellness Network"
    }
  ];

  return (
    <section className="py-24 bg-gradient-to-b from-blue-50 to-white dark:from-gray-800 dark:to-gray-900">
      <div className="max-w-7xl mx-auto px-6">
        <h2 className="text-3xl font-bold text-center mb-16 dark:text-white animate-slide-in">
          What Our Clients Say
        </h2>
        <div className="grid grid-cols-1 md:grid-cols-3 gap-8">
          {testimonials.map((testimonial, index) => (
            <div 
              key={index}
              className="bg-white dark:bg-gray-800 p-8 rounded-2xl shadow-lg transform hover:-translate-y-1 transition-transform duration-300 animate-slide-in"
            >
              <Quote className="w-10 h-10 text-blue-500 mb-6" />
              <p className="text-gray-600 dark:text-gray-300 mb-6 italic">
                "{testimonial.quote}"
              </p>
              <div>
                <p className="font-semibold text-gray-800 dark:text-white">
                  {testimonial.author}
                </p>
                <p className="text-sm text-gray-500 dark:text-gray-400">
                  {testimonial.role}
                </p>
                <p className="text-sm text-blue-500">
                  {testimonial.organization}
                </p>
              </div>
            </div>
          ))}
        </div>
      </div>
    </section>
  );
}