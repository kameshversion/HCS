import React, { useState } from 'react';
import { Dialog, Transition } from '@headlessui/react';
import { format, addDays, setHours, setMinutes } from 'date-fns';
import { X, Calendar, Clock, CreditCard } from 'lucide-react';
import { loadStripe } from '@stripe/stripe-js';

const stripePromise = loadStripe('your_publishable_key');

interface BookingModalProps {
  isOpen: boolean;
  onClose: () => void;
}

export function BookingModal({ isOpen, onClose }: BookingModalProps) {
  const [step, setStep] = useState(1);
  const [selectedDate, setSelectedDate] = useState<Date | null>(null);
  const [selectedTime, setSelectedTime] = useState<string | null>(null);
  const [isFirstTime, setIsFirstTime] = useState(true);
  const [bookingComplete, setBookingComplete] = useState(false);

  // Generate available dates (next 7 days)
  const availableDates = Array.from({ length: 7 }, (_, i) => addDays(new Date(), i + 1));

  // Generate available time slots
  const timeSlots = Array.from({ length: 8 }, (_, i) => {
    const time = setMinutes(setHours(new Date(), 9 + Math.floor(i)), (i % 2) * 30);
    return format(time, 'HH:mm');
  });

  const handleDateSelect = (date: Date) => {
    setSelectedDate(date);
    setStep(2);
  };

  const handleTimeSelect = (time: string) => {
    setSelectedTime(time);
    setStep(3);
  };

  const handlePayment = async () => {
    if (isFirstTime) {
      // First session is free
      setBookingComplete(true);
    } else {
      // Handle payment for subsequent sessions
      const stripe = await stripePromise;
      if (!stripe) return;

      // Here you would typically make an API call to your backend to create a payment intent
      // For demo purposes, we'll just show the success state
      setBookingComplete(true);
    }
  };

  const handleClose = () => {
    setStep(1);
    setSelectedDate(null);
    setSelectedTime(null);
    setBookingComplete(false);
    onClose();
  };

  return (
    <Transition show={isOpen} as={React.Fragment}>
      <Dialog onClose={handleClose} className="relative z-50">
        <Transition.Child
          enter="ease-out duration-300"
          enterFrom="opacity-0"
          enterTo="opacity-100"
          leave="ease-in duration-200"
          leaveFrom="opacity-100"
          leaveTo="opacity-0"
        >
          <div className="fixed inset-0 bg-black/30" />
        </Transition.Child>

        <div className="fixed inset-0 overflow-y-auto">
          <div className="flex min-h-full items-center justify-center p-4">
            <Transition.Child
              enter="ease-out duration-300"
              enterFrom="opacity-0 scale-95"
              enterTo="opacity-100 scale-100"
              leave="ease-in duration-200"
              leaveFrom="opacity-100 scale-100"
              leaveTo="opacity-0 scale-95"
            >
              <Dialog.Panel className="w-full max-w-md transform overflow-hidden rounded-2xl bg-white dark:bg-gray-800 p-6 text-left align-middle shadow-xl transition-all">
                <div className="flex justify-between items-center mb-6">
                  <Dialog.Title className="text-lg font-medium text-gray-900 dark:text-white">
                    {bookingComplete ? 'Booking Confirmed!' : 'Book a Demo'}
                  </Dialog.Title>
                  <button
                    onClick={handleClose}
                    className="text-gray-400 hover:text-gray-500"
                  >
                    <X className="w-5 h-5" />
                  </button>
                </div>

                {bookingComplete ? (
                  <div className="text-center py-8">
                    <div className="w-16 h-16 bg-green-100 rounded-full flex items-center justify-center mx-auto mb-4">
                      <Calendar className="w-8 h-8 text-green-500" />
                    </div>
                    <h3 className="text-xl font-semibold mb-2 dark:text-white">
                      Your demo is scheduled!
                    </h3>
                    <p className="text-gray-600 dark:text-gray-300 mb-6">
                      {selectedDate && selectedTime && `${format(selectedDate, 'MMMM d, yyyy')} at ${selectedTime}`}
                    </p>
                    <button
                      onClick={handleClose}
                      className="bg-blue-500 text-white px-6 py-2 rounded-lg hover:bg-blue-600 transition-colors"
                    >
                      Done
                    </button>
                  </div>
                ) : (
                  <div>
                    {/* Progress Steps */}
                    <div className="flex justify-between mb-8">
                      {[1, 2, 3].map((i) => (
                        <div
                          key={i}
                          className={`flex items-center ${i < 3 ? 'flex-1' : ''}`}
                        >
                          <div
                            className={`w-8 h-8 rounded-full flex items-center justify-center ${
                              step >= i
                                ? 'bg-blue-500 text-white'
                                : 'bg-gray-200 text-gray-400'
                            }`}
                          >
                            {i}
                          </div>
                          {i < 3 && (
                            <div
                              className={`flex-1 h-1 mx-2 ${
                                step > i ? 'bg-blue-500' : 'bg-gray-200'
                              }`}
                            />
                          )}
                        </div>
                      ))}
                    </div>

                    {/* Step 1: Date Selection */}
                    {step === 1 && (
                      <div>
                        <h3 className="text-lg font-medium mb-4 dark:text-white">
                          Select a Date
                        </h3>
                        <div className="grid grid-cols-2 gap-3">
                          {availableDates.map((date) => (
                            <button
                              key={date.toISOString()}
                              onClick={() => handleDateSelect(date)}
                              className="p-3 text-center border rounded-lg hover:border-blue-500 hover:bg-blue-50 dark:hover:bg-blue-900/20 transition-colors dark:border-gray-600 dark:text-white"
                            >
                              {format(date, 'MMM d, EEE')}
                            </button>
                          ))}
                        </div>
                      </div>
                    )}

                    {/* Step 2: Time Selection */}
                    {step === 2 && (
                      <div>
                        <h3 className="text-lg font-medium mb-4 dark:text-white">
                          Select a Time
                        </h3>
                        <div className="grid grid-cols-2 gap-3">
                          {timeSlots.map((time) => (
                            <button
                              key={time}
                              onClick={() => handleTimeSelect(time)}
                              className="p-3 text-center border rounded-lg hover:border-blue-500 hover:bg-blue-50 dark:hover:bg-blue-900/20 transition-colors dark:border-gray-600 dark:text-white"
                            >
                              {time}
                            </button>
                          ))}
                        </div>
                      </div>
                    )}

                    {/* Step 3: Payment/Confirmation */}
                    {step === 3 && (
                      <div>
                        <h3 className="text-lg font-medium mb-4 dark:text-white">
                          Confirm Booking
                        </h3>
                        <div className="bg-gray-50 dark:bg-gray-700/50 p-4 rounded-lg mb-6">
                          <div className="flex items-center mb-3">
                            <Calendar className="w-5 h-5 text-gray-400 mr-2" />
                            <span className="dark:text-white">
                              {selectedDate && format(selectedDate, 'MMMM d, yyyy')}
                            </span>
                          </div>
                          <div className="flex items-center">
                            <Clock className="w-5 h-5 text-gray-400 mr-2" />
                            <span className="dark:text-white">{selectedTime}</span>
                          </div>
                        </div>

                        <div className="mb-6">
                          <label className="flex items-center">
                            <input
                              type="checkbox"
                              checked={isFirstTime}
                              onChange={(e) => setIsFirstTime(e.target.checked)}
                              className="rounded text-blue-500 mr-2"
                            />
                            <span className="text-sm text-gray-600 dark:text-gray-300">
                              This is my first demo session
                            </span>
                          </label>
                        </div>

                        {!isFirstTime && (
                          <div className="mb-6">
                            <div className="flex items-center mb-2">
                              <CreditCard className="w-5 h-5 text-gray-400 mr-2" />
                              <span className="text-gray-600 dark:text-gray-300">
                                Payment Required
                              </span>
                            </div>
                            <p className="text-sm text-gray-500 dark:text-gray-400">
                              30-minute session: $50
                            </p>
                          </div>
                        )}

                        <button
                          onClick={handlePayment}
                          className="w-full bg-blue-500 text-white py-2 rounded-lg hover:bg-blue-600 transition-colors"
                        >
                          {isFirstTime ? 'Book Free Session' : 'Proceed to Payment'}
                        </button>
                      </div>
                    )}
                  </div>
                )}
              </Dialog.Panel>
            </Transition.Child>
          </div>
        </div>
      </Dialog>
    </Transition>
  );
}