import React, { useState } from 'react';
import { ChevronDown } from 'lucide-react';
import { ThemeToggle } from './ThemeToggle';

interface ContactPageProps {
  onBack: () => void;
  dropdownMenus: Record<string, string[]>;
  Logo: React.ComponentType;
}

export function ContactPage({ onBack, dropdownMenus, Logo }: ContactPageProps) {
  const [activeDropdown, setActiveDropdown] = useState<string | null>(null);

  return (
    <div className="min-h-screen bg-[#F0F9FF] dark:bg-gray-900 transition-colors duration-200">
      {/* Header */}
      <header className="bg-white dark:bg-gray-800 py-4 px-6 shadow-sm dark:shadow-gray-800/50 fixed w-full z-50">
        <div className="max-w-7xl mx-auto flex justify-between items-center">
          <div className="flex items-center space-x-12">
            {/* Logo */}
            <Logo />

            {/* Navigation */}
            <nav className="hidden lg:flex items-center space-x-8">
              {Object.entries(dropdownMenus).map(([menu, items]) => (
                <div key={menu} className="relative">
                  <button 
                    className="flex items-center space-x-1 text-gray-700 dark:text-gray-200 hover:text-emerald-600 dark:hover:text-emerald-400 transition-colors"
                    onMouseEnter={() => setActiveDropdown(menu)}
                    onClick={() => setActiveDropdown(activeDropdown === menu ? null : menu)}
                  >
                    {menu}
                    <ChevronDown className="ml-1 h-4 w-4" />
                  </button>
                  {activeDropdown === menu && (
                    <div 
                      className="absolute top-full left-0 mt-1 w-48 bg-white dark:bg-gray-800 rounded-md shadow-lg py-2"
                      onMouseLeave={() => setActiveDropdown(null)}
                    >
                      {items.map((item) => (
                        <a
                          key={item}
                          href="#"
                          className="block px-4 py-2 text-sm text-gray-700 dark:text-gray-300 hover:bg-emerald-50 dark:hover:bg-emerald-900/20 hover:text-emerald-600 dark:hover:text-emerald-400"
                        >
                          {item}
                        </a>
                      ))}
                    </div>
                  )}
                </div>
              ))}
              <button 
                onClick={onBack}
                className="text-gray-700 dark:text-gray-200 hover:text-emerald-600 dark:hover:text-emerald-400 transition-colors"
              >
                Contact Us
              </button>
            </nav>
          </div>

          <div className="flex items-center space-x-4">
            <ThemeToggle />
            <button className="bg-emerald-500 text-white px-6 py-2 rounded-full hover:bg-emerald-600 transition-colors">
              Book a Demo
            </button>
          </div>
        </div>
      </header>

      {/* Main Content */}
      <main className="pt-24">
        {/* Top Section with Contact Info and Map */}
        <div className="bg-white dark:bg-gray-800 shadow-sm">
          <div className="max-w-7xl mx-auto px-6 py-12">
            <div className="text-center mb-16">
              <h1 className="text-4xl text-gray-800 dark:text-white mb-8">Contact Us</h1>
              <p className="text-2xl text-gray-700 dark:text-gray-200">We'd love to hear from you!</p>
              <p className="text-2xl text-gray-600 dark:text-gray-300 mt-2">How can we help?</p>
            </div>

            <div className="grid grid-cols-1 lg:grid-cols-2 gap-16">
              {/* Contact Information */}
              <div>
                <h2 className="text-xl font-medium mb-8 dark:text-white">Contact Information</h2>
                <div className="space-y-8">
                  <div>
                    <p className="text-gray-700 dark:text-gray-300">5755 Carmichael Parkway</p>
                    <p className="text-gray-700 dark:text-gray-300">Montgomery, AL 36117</p>
                  </div>

                  <div className="grid grid-cols-2 gap-8">
                    <div>
                      <h3 className="font-medium mb-1 dark:text-white">Phone</h3>
                      <p className="text-gray-600 dark:text-gray-400">(334) 279-9711</p>
                    </div>
                    <div>
                      <h3 className="font-medium mb-1 dark:text-white">Fax</h3>
                      <p className="text-gray-600 dark:text-gray-400">(334) 279-0711</p>
                    </div>
                  </div>

                  <div className="space-y-4">
                    <div>
                      <h3 className="font-medium mb-1 dark:text-white">Sales</h3>
                      <a href="mailto:sales@hcsinc.net" className="text-emerald-500 hover:text-emerald-600 transition-colors">
                        sales@hcsinc.net
                      </a>
                    </div>
                    <div>
                      <h3 className="font-medium mb-1 dark:text-white">Support</h3>
                      <a href="mailto:hcssupport@hcsinc.net" className="text-emerald-500 hover:text-emerald-600 transition-colors">
                        hcssupport@hcsinc.net
                      </a>
                    </div>
                    <div>
                      <h3 className="font-medium mb-1 dark:text-white">Accounting</h3>
                      <a href="mailto:accounting@hcsinc.net" className="text-emerald-500 hover:text-emerald-600 transition-colors">
                        accounting@hcsinc.net
                      </a>
                    </div>
                  </div>
                </div>
              </div>

              {/* Map Container */}
              <div className="space-y-4">
                <div className="h-[400px]">
                  <iframe
                    src="https://www.google.com/maps/embed?pb=!1m18!1m12!1m3!1d3382.5377428857424!2d-86.2027493!3d32.3805799!2m3!1f0!2f0!3f0!3m2!1i1024!2i768!4f13.1!3m3!1m2!1s0x888c2c12e6e4bd01%3A0x6c135b953d603ea5!2s5755%20Carmichael%20Pkwy%2C%20Montgomery%2C%20AL%2036117!5e0!3m2!1sen!2sus!4v1709847854611!5m2!1sen!2sus"
                    width="100%"
                    height="100%"
                    style={{ border: 0 }}
                    allowFullScreen
                    loading="lazy"
                    referrerPolicy="no-referrer-when-downgrade"
                    className="rounded-lg shadow-md dark:shadow-gray-800/50"
                  ></iframe>
                </div>
                <a 
                  href="https://www.google.com/maps/dir//5755+Carmichael+Pkwy,+Montgomery,+AL+36117" 
                  target="_blank"
                  rel="noopener noreferrer"
                  className="inline-block bg-emerald-500 text-white px-6 py-2.5 rounded-lg hover:bg-emerald-600 transition-colors text-sm font-medium"
                >
                  Get Directions
                </a>
              </div>
            </div>
          </div>
        </div>

        {/* Contact Form Section */}
        <div className="max-w-3xl mx-auto px-6 py-12">
          <form className="bg-white dark:bg-gray-800 rounded-xl shadow-lg p-8 space-y-8">
            <h2 className="text-2xl font-medium mb-8 dark:text-white">Send us a message</h2>
            
            <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
              <div>
                <label className="block text-sm text-gray-600 dark:text-gray-400 mb-1">Name *</label>
                <input
                  type="text"
                  required
                  className="w-full px-3 py-2 border-b border-gray-300 dark:border-gray-600 focus:border-emerald-500 dark:focus:border-emerald-500 focus:outline-none bg-transparent dark:text-white"
                />
              </div>
              <div>
                <label className="block text-sm text-gray-600 dark:text-gray-400 mb-1">Email *</label>
                <input
                  type="email"
                  required
                  className="w-full px-3 py-2 border-b border-gray-300 dark:border-gray-600 focus:border-emerald-500 dark:focus:border-emerald-500 focus:outline-none bg-transparent dark:text-white"
                />
              </div>
            </div>

            <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
              <div>
                <label className="block text-sm text-gray-600 dark:text-gray-400 mb-1">Phone</label>
                <input
                  type="tel"
                  className="w-full px-3 py-2 border-b border-gray-300 dark:border-gray-600 focus:border-emerald-500 dark:focus:border-emerald-500 focus:outline-none bg-transparent dark:text-white"
                />
              </div>
              <div>
                <label className="block text-sm text-gray-600 dark:text-gray-400 mb-1">Title *</label>
                <input
                  type="text"
                  required
                  className="w-full px-3 py-2 border-b border-gray-300 dark:border-gray-600 focus:border-emerald-500 dark:focus:border-emerald-500 focus:outline-none bg-transparent dark:text-white"
                />
              </div>
            </div>

            <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
              <div>
                <label className="block text-sm text-gray-600 dark:text-gray-400 mb-1">Organization *</label>
                <input
                  type="text"
                  required
                  className="w-full px-3 py-2 border-b border-gray-300 dark:border-gray-600 focus:border-emerald-500 dark:focus:border-emerald-500 focus:outline-none bg-transparent dark:text-white"
                />
              </div>
              <div>
                <label className="block text-sm text-gray-600 dark:text-gray-400 mb-1">City, State *</label>
                <input
                  type="text"
                  required
                  className="w-full px-3 py-2 border-b border-gray-300 dark:border-gray-600 focus:border-emerald-500 dark:focus:border-emerald-500 focus:outline-none bg-transparent dark:text-white"
                />
              </div>
            </div>

            <div>
              <label className="block text-sm text-gray-600 dark:text-gray-400 mb-1">Comments *</label>
              <textarea
                required
                rows={6}
                className="w-full px-3 py-2 border-b border-gray-300 dark:border-gray-600 focus:border-emerald-500 dark:focus:border-emerald-500 focus:outline-none bg-transparent resize-none dark:text-white"
              ></textarea>
            </div>

            <div className="space-y-4">
              <div className="g-recaptcha" data-sitekey="your-recaptcha-site-key"></div>
              <button
                type="submit"
                className="bg-emerald-500 text-white px-8 py-2 rounded hover:bg-emerald-600 transition-colors"
              >
                Submit
              </button>
            </div>
          </form>
        </div>
      </main>

      {/* Footer */}
      <footer className="bg-white dark:bg-gray-800 mt-12 py-12">
        <div className="max-w-7xl mx-auto px-6">
          <div className="grid grid-cols-1 md:grid-cols-4 gap-8">
            <div>
              <div className="mb-4">
                <Logo />
              </div>
              <a href="#" className="text-emerald-500 hover:text-emerald-600 transition-colors">LinkedIn</a>
            </div>

            <div>
              <h3 className="font-medium mb-4 dark:text-white">Who we are</h3>
              <ul className="space-y-2">
                <li><a href="#" className="text-emerald-500 hover:text-emerald-600 transition-colors">Overview</a></li>
                <li><a href="#" className="text-emerald-500 hover:text-emerald-600 transition-colors">Experience</a></li>
              </ul>
            </div>

            <div>
              <h3 className="font-medium mb-4 dark:text-white">Support</h3>
              <ul className="space-y-2">
                <li><a href="#" className="text-emerald-500 hover:text-emerald-600 transition-colors">Software Support</a></li>
                <li><a href="#" className="text-emerald-500 hover:text-emerald-600 transition-colors">Virtual Training</a></li>
              </ul>
            </div>

            <div>
              <h3 className="font-medium mb-4 dark:text-white">Contact Us</h3>
              <p className="text-gray-600 dark:text-gray-400">5755 Carmichael Parkway</p>
              <p className="text-gray-600 dark:text-gray-400 mb-4">Montgomery, AL 36117</p>
              <button className="bg-emerald-500 text-white px-6 py-2 rounded-full hover:bg-emerald-600 transition-colors">
                Book a Demo
              </button>
            </div>
          </div>
        </div>
      </footer>
    </div>
  );
}