import { useState } from 'react';
import { Calculator } from 'lucide-react';

export function PricingCalculator() {
  const [isOpen, setIsOpen] = useState(false);
  const [users, setUsers] = useState(10);
  const [modules, setModules] = useState(['clinical']);

  const basePrice = 199;
  const userPrice = 49;
  const modulesPricing = {
    clinical: 299,
    financial: 199,
    operational: 249,
    compliance: 179
  };

  const totalPrice = basePrice + (users * userPrice) + 
    modules.reduce((acc, mod) => acc + modulesPricing[mod as keyof typeof modulesPricing], 0);

  return (
    <div className="fixed bottom-4 left-4 z-50">
      <button
        onClick={() => setIsOpen(!isOpen)}
        className="bg-green-500 hover:bg-green-600 text-white rounded-full p-4 shadow-lg transition-colors"
      >
        <Calculator className="w-6 h-6" />
      </button>

      {isOpen && (
        <div className="absolute bottom-16 left-0 bg-white dark:bg-gray-800 rounded-lg shadow-xl p-6 w-80">
          <h3 className="text-lg font-semibold mb-4 dark:text-white">Pricing Calculator</h3>
          
          <div className="space-y-4">
            <div>
              <label className="block text-sm font-medium text-gray-700 dark:text-gray-300 mb-1">
                Number of Users
              </label>
              <input
                type="range"
                min="1"
                max="100"
                value={users}
                onChange={(e) => setUsers(Number(e.target.value))}
                className="w-full"
              />
              <span className="text-sm text-gray-600 dark:text-gray-400">{users} users</span>
            </div>

            <div>
              <label className="block text-sm font-medium text-gray-700 dark:text-gray-300 mb-1">
                Modules
              </label>
              {Object.keys(modulesPricing).map((mod) => (
                <label key={mod} className="flex items-center space-x-2">
                  <input
                    type="checkbox"
                    checked={modules.includes(mod)}
                    onChange={(e) => {
                      if (e.target.checked) {
                        setModules([...modules, mod]);
                      } else {
                        setModules(modules.filter(m => m !== mod));
                      }
                    }}
                    className="rounded text-blue-500"
                  />
                  <span className="text-sm capitalize dark:text-white">{mod}</span>
                </label>
              ))}
            </div>

            <div className="mt-4 pt-4 border-t dark:border-gray-700">
              <div className="flex justify-between items-center">
                <span className="font-semibold dark:text-white">Estimated Total</span>
                <span className="text-2xl font-bold text-green-500">${totalPrice}/mo</span>
              </div>
            </div>
          </div>
        </div>
      )}
    </div>
  );
}